from .mandelbrot import *

__doc__ = mandelbrot.__doc__
if hasattr(mandelbrot, "__all__"):
    __all__ = mandelbrot.__all__